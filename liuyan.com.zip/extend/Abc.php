<?php
/**
 * 扩展演示
 * @copyright 2020-2021 WillPHP
 * @author NoMind<24203741@qq.com/113344.com>
 * @version WillPHPv2
 * @since 2021年7月21日 上午11:49:21
 */ 
namespace extend;
class Abc {
	public function test() {
		return 'test ok';
	}
}