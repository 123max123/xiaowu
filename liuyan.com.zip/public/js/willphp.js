//显示提示信息
function showtip(tip,time=2){
	layer.open({content:tip, time:time, skin: 'msg'});
}
//表单ajax提交
$('.submit-ajax').submit(function(){
    var url = $(this).attr('action');
    var data = $(this).serialize();
	$.post(url,data,function(res){					
		if (res.status == 1) {						
			showtip(res.info);
            setTimeout(function(){
                window.location.href = res.url;
            },2000);			
		} else {
			showtip(res.info);
		}
	},'json');
    return false;
}); 
//ajax链接 refresh:1跳转url;2页面重新加载3只提示信息
function ajaxLink(url,refresh=1) {
	$.get(url,function(res){					
		if (res.status == 1) {						
			showtip(res.info);
			if (refresh == 1) {
	            setTimeout(function(){
	                window.location.href = res.url;
	            },2000);					
			} else if (refresh == 2) {
	            setTimeout(function(){
	            	location.reload();
	            },2000);					
			}		
		} else {
			showtip(res.info);
		}
	},'json');	
}
//ajax操作 
function actionLink(url,action='删除',refresh=1) {
	var msg = '确认要'+action+'吗？';
	layer.open({content:msg,btn:['确认','取消'],yes:function(index){			
			ajaxLink(url,refresh);			
			layer.close(index);
		}
	});
}
//全选
function selectAll(selectStatus){	 
	  if(selectStatus){
	    $("input[name='ids']").each(function(i,n){
	      n.checked = true;
	    });
	  }else{
	    $("input[name='ids']").each(function(i,n){
	      n.checked = false;
	    });
	  }
}
//操作选择项
function actionAll(action,url) {
	var ids = [];	
	$('tbody input').each(function(index, el) {
		if($(this).prop('checked')){
			ids.push($(this).val())
		}
	});	
	var msg = '确认要'+action+'吗？'+ids.toString();
	layer.open({content:msg,btn:['确认','取消'],yes:function(index){			
			$.post(url,{ids:ids},function(res){					
				if (res.status == 1) {						
					showtip(res.info);				
		            setTimeout(function(){
		            	location.reload();
		            },2000);				
				} else {
					showtip(res.info);
				}
			},'json'); 				
			layer.close(index);
		}
	});	
}