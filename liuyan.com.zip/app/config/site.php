<?php
return array (
  'site_title' => '留言板',
  'site_kw' => '留言板',
  'site_desc' => '留言板',
  'site_about' => '留言板',
  'site_h1' => '一鱼留言评论',
  'site_h2' => '留言板',
  'site_logo' => '留言板',
  'gbook_about' => '文明上网，理性发言！填写QQ将自动获取QQ头像！',
);