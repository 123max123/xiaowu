<?php
namespace app\controller;
class AbcController extends BaseController{
	public function abc(){
		return view();
	}
}