<?php
/**
 * 公共网站配置
 * @copyright 2020-2021 WillPHP
 * @author NoMind<24203741@qq.com/113344.com>
 * @version WillPHPv2
 * @since 2021-07-26
 */
return [
		'theme' => 'default', //主题设置
		'site_title' => '欢迎使用一鱼PHP框架-WillPHP',
		'site_h1' => '一鱼PHP框架',
];