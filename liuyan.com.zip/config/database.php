<?php
return array (
  'db_host' => 'localhost',
  'db_user' => 'liuyan_com',
  'db_pwd' => 'liuyan_com',
  'db_name' => 'liuyan_com',
  'table_pre' => 'ly_',
  'db_type' => 'mysqli',
  'db_port' => '3306',
  'db_charset' => 'utf8',
);