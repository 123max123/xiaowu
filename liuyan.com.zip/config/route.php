<?php
/**
 * 公共路由配置
 * @copyright 2020-2021 WillPHP
 * @author NoMind<24203741@qq.com/113344.com>
 * @version WillPHPv2
 * @since 2021-07-26
 */ 
return [
		'/$' => ['index/index', '*'],
];